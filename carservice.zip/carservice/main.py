from application import Application

app = Application()