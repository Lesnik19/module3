from tkinter import *


class MyLabel:
    def __init__(self, x, y, text, font, bg_color):
        self.label = Label(text=text, font=font, background=bg_color)
        self.label.place(x=x, y=y)
