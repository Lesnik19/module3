import sqlite3


class Database:
    def __init__(self, name):
        self.name = name
        self.connector = sqlite3.connect(self.name)
        self.cursor = self.connector.cursor()
        self.request = ''

    def select_sql(self, request):
        self.request = request
        return self.cursor.execute(self.request)

    def close_db(self):
        self.connector.commit()
        self.cursor.close()
        self.connector.close()
