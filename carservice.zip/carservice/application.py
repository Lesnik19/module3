from tkinter import *
from my_label import MyLabel
from myEntry import MyEntry


class Application:
    def __init__(self):
        self.window = Tk()
        self.window.geometry('400x400')
        self.window.resizable(height=False, width=False)
        self.window.title('Авторизация')
        self.window.configure(background='lightgreen')
        self.create_widgets()
        self.window.mainloop()

    def create_widgets(self):
        self.title_label = MyLabel(120, 50, 'Авторизация', 'Arial 18 bold', 'lightgreen')
        self.login_label = MyLabel(40, 130, 'Логин', 'Arial 14', 'lightgreen')
        self.password_label = MyLabel(40, 190, 'Пароль', 'Arial 14', 'lightgreen')

        self.login_entry = MyEntry(130, 130, 'Arial 14', 200)
        self.password_entry = MyEntry(130, 190, 'Arial 14', 200, False)
